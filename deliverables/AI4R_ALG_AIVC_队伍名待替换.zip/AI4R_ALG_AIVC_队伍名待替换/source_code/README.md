# M12.0 源码复现说明

## 目录

```text
source_code/
├── go_ai/
│   ├── src/                 # baseline、M2/M6/M7/M8 与图模型实现
│   ├── scripts/             # OOF、实体审计、融合、路由和报告脚本
│   ├── configs/             # 固定实验配置
│   ├── tests/
│   └── pyproject.toml
├── goai_rna_transfer/
│   ├── src/                 # OP3/L1000 预训练、M9 OOF/refit、M11/M12 比较
│   ├── configs/
│   └── tests/
├── requirements.txt
└── environment.lock.txt
```

官方数据、外部数据、checkpoint、OOF/test prediction、缓存和运行日志均未打包。

## 环境

记录实验运行在 Python 3.8.20 + CUDA 12.4。建议新建隔离环境：

```bash
conda create -n goai-m12 python=3.8.20 -y
conda activate goai-m12
python -m pip install -r requirements.txt
```

GPU 版 PyTorch 应按服务器 CUDA 版本从 PyTorch 官方索引安装。`requirements.txt`
中的版本用于说明已验证组合，不要求评委机器逐字复刻 CUDA build tag。

设置源码路径：

```bash
export GOAI_CODE="$PWD/go_ai"
export RNA_CODE="$PWD/goai_rna_transfer"
export PYTHONPATH="$GOAI_CODE/src:$RNA_CODE:$PYTHONPATH"
```

## 数据路径

把赛事文件放在本地受控目录，修改以下配置中的路径：

- `go_ai/configs/baseline.yaml`
- `goai_rna_transfer/configs/experiment.yaml`

需要的官方文件名：

```text
WAYB_WAYC_metadata_train_val.csv
WAYB_WAYC_proteome_raw_train_val.csv
WAYB_WAYC_metadata_test.csv
```

外部 OP3 数据路径只在开放知识实验配置中设置，来源和许可见包根目录
`EXTERNAL_RESOURCES.md`。

## 1. 数据审计与最小基线

```bash
cd "$GOAI_CODE"
python -m goai_baseline.audit --config configs/baseline.yaml
python -m goai_baseline.preprocess \
  --config configs/baseline.yaml \
  --output runs/preprocess/feature_contract.json
python -m goai_baseline.evaluate \
  --config configs/baseline.yaml \
  --variant b0_mean \
  --output-dir runs/b0_mean
```

## 2. M6 cell-conditioned 主干

核心配置：

- S1：`go_ai/configs/experiments/response_conditional_concat_l256.yaml`
- time：`go_ai/configs/experiments/response_conditional_film_l256.yaml`

示例：

```bash
cd "$GOAI_CODE"
python -m goai_graph.conditional_train \
  --config configs/experiments/response_conditional_concat_l256.yaml
```

最终记录 seeds 为 `42/43/2026`。每个 seed 必须单独修改配置或命令参数，并保存
checkpoint、fold assignment、feature contract、manifest 和 OOF prediction。

## 3. M9.6 OP3 RNA chemical residual

先验证外部 OP3 输入并训练 real/shuffled encoder，再跑四折 S1：

```bash
cd "$RNA_CODE"
python -m src.rna_pretrain prepare --config configs/experiment.yaml --skip-cv
python -m src.rna_pretrain train \
  --config configs/experiment.yaml \
  --label-mode real \
  --device cuda:0
python -m src.rna_pretrain train \
  --config configs/experiment.yaml \
  --label-mode input-shuffle \
  --device cuda:0

for fold in 0 1 2 3; do
  python -m src.train_s1 \
    --config configs/experiment.yaml \
    --arm op3_real_residual_s02 \
    --fold "$fold" \
    --seed 42 \
    --device cuda:0
done
```

对 `43/2026` 重复相同四折。real 与 shuffled 必须使用相同 fold、seed、下游网络和
训练轮数；只有 chemical encoder 标签映射不同。

全量 refit 入口：

```bash
python -m src.refit_m9_response \
  --config configs/experiment.yaml \
  --seed 42 \
  --device cuda:0
```

## 4. M12 固定融合与路由

M12.0 复用 M6/M9.6 三 seed refit，只有 R10 行启用：

```text
blend = -0.075 * R6 + 1.075 * R9.6
gate  = I(abs(R6) >= 0.5)
R12   = blend + 0.15 * gate * (R6 - blend)
final = B6 + C6 + R12
```

融合脚本：`go_ai/scripts/predict_m11_score_sprint.py`。固定参数：

```bash
python go_ai/scripts/predict_m11_score_sprint.py \
  --mode high_specialist \
  --weight 1.075 \
  --specialist-threshold 0.5 \
  --specialist-takeover 0.15 \
  --override-route R10
```

实际路径参数以 `--help` 为准。每行 route 必须基于当前 fit rows 的 canonical
strain/chemical support 重新计算，禁止只按 `split_final` 粗路由。

## 5. 评估纪律

- 新化合物：held-out chemical 的所有行从 fold train 移除。
- 新菌株：held-out strain 的所有行从 fold train 移除。
- 双未知：held-out strain 与 chemical 的全部相关行均移除。
- scaler、SVD/PCA、target prototype、支持词表和融合权重只能在 fold train/inner OOF 拟合。
- 报告 FC PCC，同时报告 Context/Drug residual、High PCC、High F1 和 Abs R2。
- response-only 模型不得与完整模型比较 absolute R2。

## 6. 测试

```bash
cd "$GOAI_CODE"
pytest -q

cd "$RNA_CODE"
pytest -q
```

冻结结果记录为 `go-ai: 204 passed`，`goai-rna-transfer: 14 passed`。

## 7. 已知限制

- M9.6 依赖外部 OP3 数据，提交/公开前必须确认 GOAI 最新外部数据规则。
- 新菌株与双未知仍由 M5.2/M2 路径承担；SNP-MDS 与双语义实验未通过最终提升门禁。
- 本包不含权重，所以完整数值复现需要按上述流程重新训练。
- 历史 M6 三个 refit 目录中的旧 `manifest.json` 都记录 seed 42；真实 seed 身份以
  checkpoint 路径和 SHA256 为准。该 provenance 瑕疵已在内部审计中登记。
