# GOAI 虚拟酵母扰动响应预测 - 初赛附件

作品名称：虚拟酵母扰动响应预测：共享细胞状态与 OOD 分层融合  
队伍名称：`队伍名待替换`  
赛题：题目类型一（算法赛题）- 虚拟细胞  
当前模型：`GOAI-M12.0`  
材料版本：2026-08-15

## 上传前只需完成一项

将队伍名告诉项目维护者，随后同时替换：

1. 本 README 和方案文档封面的 `队伍名待替换`；
2. ZIP 文件名中的占位符，最终名称必须为 `AI4R_ALG_AIVC_实际队伍名.zip`。

除队伍名外，本包已经按算法赛附件要求组织。不要把当前占位符版本直接上传。

## 包内内容

- `初赛方案说明.pdf`：评委优先阅读版本。
- `初赛方案说明.docx`：可编辑版本。
- `source_code/`：M6、M9.6、M12 融合与 OOD 验证源码、配置、测试和环境说明。
- `results/`：主要结果表、关键图和验证口径说明。
- `EXTERNAL_RESOURCES.md`：外部数据、预训练、软件依赖、许可与未打包资源。
- `PACKAGE_MANIFEST.json`：文件大小、SHA256、排除项和提交状态。

## 方法与结果摘要

M12.0 将细胞基础状态、处理响应和观测校准分开建模，但 Background 与 Response
共享 cell encoder，避免三个生物分支彼此完全独立。对新化合物场景，模型融合
M6 的 cell-conditioned response 与 M9.6 的 OP3 RNA 预训练化学 residual，并在
M6 预测的大效应位置做固定比例回拉。

严格 chemical-held-out OOF 的主要结果：

| 模型 | FC PCC | Context PCC | High PCC | High F1 | Abs R2 |
|---|---:|---:|---:|---:|---:|
| M6 core | 0.371973 | 0.098530 | 0.635746 | 0.182687 | 0.979300 |
| M11 blend | 0.426139 | 0.062244 | 0.600870 | 0.233938 | 0.979193 |
| **M12.0** | **0.426342** | 0.060967 | **0.603184** | **0.233970** | 0.979150 |

上述均为本地严格 OOF 代理指标，不是官方榜分。M12.0 是 FC 优先方案，Context PCC
相对 M11 有小幅下降，报告中已完整披露。

## 源码运行入口

源码包不包含官方数据、模型权重、预测文件、测试真值、缓存或运行日志。将官方三个 CSV
放到本地工作目录后，参照 `source_code/README.md` 配置绝对路径并运行：

```bash
export PYTHONPATH="$PWD/source_code/go_ai/src:$PWD/source_code/goai_rna_transfer"
python -m goai_graph.conditional_train \
  --config source_code/go_ai/configs/experiments/response_conditional_concat_l256.yaml
```

外部 OP3 encoder 的重建、S1 OOF、三 seed refit 和最终融合命令见
`source_code/README.md`。记录实验使用 seeds `42/43/2026`。

## 为什么不含 prediction.csv

当前页面的作品附件用于提交方案文档和源码；主榜预测属于单独提交物，因此本 ZIP
刻意不包含任何 test prediction。这样也避免在作品附件中错误分发数据派生产物。

## 开源边界

包内只包含团队自有实现、配置和文字材料。官方数据、外部数据、预训练权重、OOF/test
预测、checkpoint 和完整日志全部排除。代码仓库公开前仍应依据赛事最新规则再次确认
外部数据与主动公开边界。
